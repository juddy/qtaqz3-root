#!/bin/sh
# * GhettoRoot is licensed under GPLv3 or later. See file LICENSE.txt in root of package tree.
adb shell "rm -rf /data/local/tmp/ghetto"
